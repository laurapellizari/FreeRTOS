//Adapted from FreeRTOS 9.0 demo file for LPC11xx
//Using on LPC11Ux

/* FreeRTOS includes. */
#include "FreeRTOS.h"
#include "task.h"

/* Hardware specific includes. */
#include "lpc11xx.h"

#include "gpio.h"
#include "i2c.h"

#include "joystick.h"
#include "pca9532.h"


#include "ssp.h"
#include "oled.h"


#include "light.h"
#include "adc.h"



/*-----------------------------------------------------------*/
/* Perform any application specific hardware configuration.  The clocks,
 * memory, etc. are configured before main() is called.
 */
static void prvSetupHardware(void);

// TASKS prototypes


static void intToString(int value, uint8_t* pBuf){
    static const char* pAscii = "0123456789";
    int pos = 0;
    int tmpValue = value;

    // negative value
    if (value < 0){
        tmpValue = -tmpValue;
        value    = -value;
        pBuf[pos++] = '-';
    }

    // calculate the required length of the buffer
    do {
        pos++;
        tmpValue /= 10;
    } while(tmpValue > 0);

    pBuf[pos] = '\0';

    do {
        pBuf[--pos] = pAscii[value % 10];
        value /= 10;
    } while(value > 0);
    return;
}

void print_lux(void *pvParameters) {
	TickType_t xNextWakeTime;
	int lux=1687;
	uint8_t slux[10];
	/* Initialise xNextWakeTime - this only needs to be done once. */
	xNextWakeTime = xTaskGetTickCount();

	I2CInit( (uint32_t)I2CMASTER, 0 );


	oled_putString(1,20,  (uint8_t*)"Lux: ", OLED_COLOR_BLACK, OLED_COLOR_WHITE);
	light_init();
	light_enable();
	light_setRange(LIGHT_RANGE_4000);
	for (;;) {
		lux = light_read();
		intToString(lux, slux);
		oled_fillRect(35,20, 35+30, 20+8, OLED_COLOR_WHITE);
		oled_putString(35,20,  (uint8_t*)slux, OLED_COLOR_BLACK, OLED_COLOR_WHITE);

		vTaskDelayUntil(&xNextWakeTime, 1000 / portTICK_PERIOD_MS);

	}
}

void print_trim(void *pvParameters) {
	TickType_t xNextWakeTime;
	int trim;
	uint8_t strim[10];
	/* Initialise xNextWakeTime - this only needs to be done once. */
	xNextWakeTime = xTaskGetTickCount();

	ADCInit( ADC_CLK );

	oled_putString(1,40,  (uint8_t*)"Trim: ", OLED_COLOR_BLACK, OLED_COLOR_WHITE);
	for (;;) {
		trim = ADCRead(0);

		intToString(trim, strim);
		oled_fillRect(35,40, 35+30, 40+8, OLED_COLOR_WHITE);
		oled_putString(35,40,  (uint8_t*)strim, OLED_COLOR_BLACK, OLED_COLOR_WHITE);

		vTaskDelayUntil(&xNextWakeTime, 500 / portTICK_PERIOD_MS);

	}
}


/*-----------------------------------------------------------*/
int main(void) {
	/* Prepare the hardware to run this demo. */
	prvSetupHardware();

	SSP_IOConfig(0);
	SSP_Init(0);
	oled_init();

	oled_clearScreen(OLED_COLOR_WHITE);

	oled_putString(1,1,  (uint8_t*)"We need a Q!", OLED_COLOR_BLACK, OLED_COLOR_WHITE);

	xTaskCreate(print_lux,"LUX",configMINIMAL_STACK_SIZE, 0, tskIDLE_PRIORITY + 1, NULL);
	xTaskCreate(print_trim,"TRIM",configMINIMAL_STACK_SIZE, 0, tskIDLE_PRIORITY + 1, NULL);


	/* Start the tasks and timer running. */
	vTaskStartScheduler();

	return 0;
}


/*-----------------------------------------------------------*/

static void prvSetupHardware(void) {
	extern unsigned long _vStackTop[], _pvHeapStart[];
	unsigned long ulInterruptStackSize;

	/* Enable AHB clock for GPIO. */
	LPC_SYSCON->SYSAHBCLKCTRL |= (1 << 6);

	/* The size of the stack used by main and interrupts is not defined in
	 the linker, but just uses whatever RAM is left.  Calculate the amount of
	 RAM available for the main/interrupt/system stack, and check it against
	 a reasonable number.  If this assert is hit then it is likely you don't
	 have enough stack to start the kernel, or to allow interrupts to nest.
	 Note - this is separate to the stacks that are used by tasks.  The stacks
	 that are used by tasks are automatically checked if
	 configCHECK_FOR_STACK_OVERFLOW is not 0 in FreeRTOSConfig.h - but the stack
	 used by interrupts is not.  Reducing the conifgTOTAL_HEAP_SIZE setting will
	 increase the stack available to main() and interrupts. */
	ulInterruptStackSize = ((unsigned long) _vStackTop)
			- ((unsigned long) _pvHeapStart);
	configASSERT(ulInterruptStackSize > 350UL);

}
/*-----------------------------------------------------------*/

void vApplicationMallocFailedHook(void) {
	/* vApplicationMallocFailedHook() will only be called if
	 configUSE_MALLOC_FAILED_HOOK is set to 1 in FreeRTOSConfig.h.  It is a hook
	 function that will get called if a call to pvPortMalloc() fails.
	 pvPortMalloc() is called internally by the kernel whenever a task, queue,
	 timer or semaphore is created.  It is also called by various parts of the
	 demo application.  If heap_1.c or heap_2.c are used, then the size of the
	 heap available to pvPortMalloc() is defined by configTOTAL_HEAP_SIZE in
	 FreeRTOSConfig.h, and the xPortGetFreeHeapSize() API function can be used
	 to query the size of free heap space that remains (although it does not
	 provide information on how the remaining heap might be fragmented). */
	taskDISABLE_INTERRUPTS();
	for (;;)
		;
}
/*-----------------------------------------------------------*/

void vApplicationIdleHook(void) {
	/* vApplicationIdleHook() will only be called if configUSE_IDLE_HOOK is set
	 to 1 in FreeRTOSConfig.h.  It will be called on each iteration of the idle
	 task.  It is essential that code added to this hook function never attempts
	 to block in any way (for example, call xQueueReceive() with a block time
	 specified, or call vTaskDelay()).  If the application makes use of the
	 vTaskDelete() API function (as this demo application does) then it is also
	 important that vApplicationIdleHook() is permitted to return to its calling
	 function, because it is the responsibility of the idle task to clean up
	 memory allocated by the kernel to any task that has since been deleted. */
}
/*-----------------------------------------------------------*/

void vApplicationStackOverflowHook(TaskHandle_t pxTask, char *pcTaskName) {
	(void) pcTaskName;
	(void) pxTask;

	/* Run time stack overflow checking is performed if
	 configCHECK_FOR_STACK_OVERFLOW is defined to 1 or 2.  This hook
	 function is called if a stack overflow is detected. */
	taskDISABLE_INTERRUPTS();
	for (;;)
		;
}
/*-----------------------------------------------------------*/

void vApplicationTickHook(void) {
#if mainCHECK_INTERRUPT_STACK == 1
	extern unsigned long _pvHeapStart[];

	/* This function will be called by each tick interrupt if
	 configUSE_TICK_HOOK is set to 1 in FreeRTOSConfig.h.  User code can be
	 added here, but the tick hook is called from an interrupt context, so
	 code must not attempt to block, and only the interrupt safe FreeRTOS API
	 functions can be used (those that end in FromISR()). */

	/* Manually check the last few bytes of the interrupt stack to check they
	 have not been overwritten.  Note - the task stacks are automatically
	 checked for overflow if configCHECK_FOR_STACK_OVERFLOW is set to 1 or 2
	 in FreeRTOSConifg.h, but the interrupt stack is not. */
	configASSERT( memcmp( ( void * ) _pvHeapStart, ucExpectedInterruptStackValues, sizeof( ucExpectedInterruptStackValues ) ) == 0U );
#endif /* mainCHECK_INTERRUPT_STACK */
}
/*-----------------------------------------------------------*/
